/**
 * AI Verse API — Cloudflare Worker
 *
 * What it does
 *  - Sells API keys through Stripe monthly subscriptions (webhook creates the key)
 *  - Shows each new key once on the website after checkout (/v1/claim)
 *  - Serves an OpenAI-compatible API: POST /v1/chat/completions, GET /v1/models
 *  - Enforces each plan's monthly request allowance and the subscription status
 *  - Lets customers check usage (/v1/usage) and replace a key (/v1/keys/rotate)
 *  - Powers the AIV chat on the website (/site/chat) without exposing your Groq key
 *
 * Secrets (set with `wrangler secret put NAME`):
 *   GROQ_API_KEY, STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET
 * Vars (wrangler.toml): SITE_ORIGIN, PRICE_IDS
 * KV binding: AIV_KV
 *
 * Keys are stored only as SHA-256 hashes. Prompts and answers are never stored.
 */

// ---------- plans and models (edit to change your offer) ----------
const PLANS = {
  starter:  { name: 'Starter',  monthlyRequests: 5000 },
  pro:      { name: 'Pro',      monthlyRequests: 25000 },
  business: { name: 'Business', monthlyRequests: 100000 },
};
const MODELS = {
  'aiv-1':      { upstream: 'openai/gpt-oss-120b', description: 'AIV standard model — best quality' },
  'aiv-1-mini': { upstream: 'openai/gpt-oss-20b',  description: 'AIV fast model — lower latency' },
};
const DEFAULT_MODEL = 'aiv-1';
const MAX_OUTPUT_TOKENS = 2048;
const MAX_BODY_BYTES = 64000;
const SITE_CHAT_PER_HOUR = 30;           // per visitor IP, for the website chat
const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';
const ACTIVE = new Set(['active', 'trialing']);
const PASSTHROUGH = ['messages', 'temperature', 'top_p', 'stream', 'stop', 'response_format', 'seed', 'tools', 'tool_choice', 'parallel_tool_calls'];

// ---------- small helpers ----------
const enc = new TextEncoder();
const cors = (origin = '*') => ({
  'Access-Control-Allow-Origin': origin,
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, Content-Type',
  'Access-Control-Max-Age': '86400',
  'Vary': 'Origin',
});
const json = (data, status = 200, origin = '*') =>
  new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json', ...cors(origin) } });
const fail = (status, message, type = 'invalid_request_error', origin = '*') =>
  json({ error: { message, type } }, status, origin);

async function sha256hex(text) {
  const buf = await crypto.subtle.digest('SHA-256', enc.encode(text));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
}
function newKey() {
  const abc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const bytes = crypto.getRandomValues(new Uint8Array(40));
  let s = '';
  for (const b of bytes) if (b < 248) s += abc[b % 62]; // drop biased values
  return 'aiv_live_' + s.slice(0, 32).padEnd(32, 'x');
}
const monthKey = (d = new Date()) => d.toISOString().slice(0, 7);
const nextMonthStart = (d = new Date()) => new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1)).toISOString().slice(0, 10);
function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
function priceMap(env) {
  try { return JSON.parse(env.PRICE_IDS || '{}'); } catch { return {}; }
}
function siteOrigins(env) {
  return String(env.SITE_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean);
}

// ---------- Stripe ----------
async function verifyStripe(body, header, secret, toleranceSec = 300) {
  if (!header || !secret) return false;
  let t = null; const v1 = [];
  for (const part of header.split(',')) {
    const [k, v] = part.split('=');
    if (k === 't') t = v; else if (k === 'v1' && v) v1.push(v);
  }
  if (!t || !v1.length) return false;
  if (Math.abs(Date.now() / 1000 - Number(t)) > toleranceSec) return false;
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(`${t}.${body}`));
  const hex = [...new Uint8Array(sig)].map(b => b.toString(16).padStart(2, '0')).join('');
  return v1.some(v => safeEqual(v, hex));
}
async function stripeGet(env, path) {
  const r = await fetch('https://api.stripe.com/v1' + path, { headers: { Authorization: 'Bearer ' + env.STRIPE_SECRET_KEY } });
  if (!r.ok) throw new Error('Stripe API error ' + r.status);
  return r.json();
}
const statusOf = s => (ACTIVE.has(s) ? 'active' : s || 'inactive');

async function handleWebhook(req, env) {
  const body = await req.text();
  const ok = await verifyStripe(body, req.headers.get('Stripe-Signature'), env.STRIPE_WEBHOOK_SECRET);
  if (!ok) return new Response('Invalid signature', { status: 400 });
  const event = JSON.parse(body);
  const obj = event.data && event.data.object || {};
  const prices = priceMap(env);
  const KV = env.AIV_KV;

  if (event.type === 'checkout.session.completed' && obj.mode === 'subscription') {
    const sub = obj.subscription;
    if (!sub) return new Response('ok');
    if (await KV.get('sub:' + sub)) return new Response('ok'); // already handled (Stripe retries)
    let plan = obj.metadata && obj.metadata.plan;
    if (!PLANS[plan]) {
      const items = await stripeGet(env, `/checkout/sessions/${obj.id}/line_items?limit=5`);
      const priceId = items.data && items.data[0] && items.data[0].price && items.data[0].price.id;
      plan = prices[priceId];
    }
    if (!PLANS[plan]) return new Response('Unknown plan for this price — check PRICE_IDS', { status: 500 });
    const key = newKey();
    const hash = await sha256hex(key);
    const record = {
      plan, status: 'active', sub, customer: obj.customer || null,
      email: (obj.customer_details && obj.customer_details.email) || obj.customer_email || null,
      created: new Date().toISOString(), last4: key.slice(-4),
    };
    await KV.put('key:' + hash, JSON.stringify(record));
    await KV.put('sub:' + sub, hash);
    await KV.put('claim:' + obj.id, JSON.stringify({ key, plan }), { expirationTtl: 3600 });
    return new Response('ok');
  }

  if (event.type === 'customer.subscription.updated' || event.type === 'customer.subscription.deleted') {
    const hash = await KV.get('sub:' + obj.id);
    if (!hash) return new Response('ok');
    const rec = JSON.parse(await KV.get('key:' + hash) || 'null');
    if (!rec) return new Response('ok');
    rec.status = event.type === 'customer.subscription.deleted' ? 'canceled' : statusOf(obj.status);
    const priceId = obj.items && obj.items.data && obj.items.data[0] && obj.items.data[0].price && obj.items.data[0].price.id;
    if (prices[priceId] && PLANS[prices[priceId]]) rec.plan = prices[priceId];
    rec.updated = new Date().toISOString();
    await KV.put('key:' + hash, JSON.stringify(rec));
    return new Response('ok');
  }

  return new Response('ok'); // ignore other events
}

// ---------- API key auth and usage ----------
async function authenticate(req, env) {
  const m = /^Bearer\s+(\S+)$/i.exec(req.headers.get('Authorization') || '');
  if (!m) return { error: fail(401, 'Missing API key. Send it as: Authorization: Bearer aiv_live_…', 'authentication_error') };
  const hash = await sha256hex(m[1]);
  const rec = JSON.parse(await env.AIV_KV.get('key:' + hash) || 'null');
  if (!rec) return { error: fail(401, 'Invalid API key.', 'authentication_error') };
  return { hash, rec };
}
async function usageOf(env, hash) {
  return Number(await env.AIV_KV.get(`use:${hash}:${monthKey()}`) || 0);
}
async function addUsage(env, hash, used) {
  await env.AIV_KV.put(`use:${hash}:${monthKey()}`, String(used + 1), { expirationTtl: 60 * 60 * 24 * 70 });
}

async function forwardToGroq(env, payload, origin, aliasName) {
  const r = await fetch(GROQ_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + env.GROQ_API_KEY },
    body: JSON.stringify(payload),
  });
  if (!r.ok) {
    let msg = 'The AI service returned an error.';
    try { const j = await r.json(); msg = (j.error && j.error.message) || msg; } catch {}
    const status = r.status === 429 ? 503 : r.status >= 500 ? 502 : r.status;
    return fail(status, r.status === 429 ? 'AIV is at capacity right now. Please retry in a few seconds.' : msg, 'upstream_error', origin);
  }
  const ct = r.headers.get('content-type') || '';
  if (payload.stream || ct.includes('text/event-stream')) {
    return new Response(r.body, { status: 200, headers: { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', ...cors(origin) } });
  }
  const j = await r.json();
  if (aliasName) j.model = aliasName;
  return json(j, 200, origin);
}

async function readJson(req) {
  const len = Number(req.headers.get('content-length') || 0);
  if (len > MAX_BODY_BYTES) throw new Error('Request body is too large (64 KB max).');
  const text = await req.text();
  if (text.length > MAX_BODY_BYTES) throw new Error('Request body is too large (64 KB max).');
  return JSON.parse(text);
}

function buildPayload(body, upstreamModel) {
  if (!Array.isArray(body.messages) || !body.messages.length) throw new Error('"messages" must be a non-empty array.');
  const out = { model: upstreamModel };
  for (const k of PASSTHROUGH) if (body[k] !== undefined) out[k] = body[k];
  const asked = Number(body.max_completion_tokens || body.max_tokens || MAX_OUTPUT_TOKENS);
  out.max_completion_tokens = Math.max(1, Math.min(MAX_OUTPUT_TOKENS, asked || MAX_OUTPUT_TOKENS));
  if (/gpt-oss/.test(upstreamModel)) out.reasoning_effort = ['low', 'medium', 'high'].includes(body.reasoning_effort) ? body.reasoning_effort : 'low';
  return out;
}

async function chatCompletions(req, env) {
  const a = await authenticate(req, env);
  if (a.error) return a.error;
  const { hash, rec } = a;
  if (rec.status !== 'active') return fail(403, `This key's subscription is ${rec.status}. Update billing to keep using the API.`, 'subscription_inactive');
  const plan = PLANS[rec.plan];
  const used = await usageOf(env, hash);
  if (used >= plan.monthlyRequests) return fail(429, `Monthly limit reached (${plan.monthlyRequests.toLocaleString()} requests on ${plan.name}). It resets on ${nextMonthStart()}, or upgrade your plan.`, 'quota_exceeded');
  let body;
  try { body = await readJson(req); } catch (e) { return fail(400, e.message || 'Request body must be JSON.'); }
  const alias = body.model || DEFAULT_MODEL;
  const model = MODELS[alias];
  if (!model) return fail(400, `Unknown model "${alias}". Available: ${Object.keys(MODELS).join(', ')}.`);
  let payload;
  try { payload = buildPayload(body, model.upstream); } catch (e) { return fail(400, e.message); }
  await addUsage(env, hash, used);
  return forwardToGroq(env, payload, '*', alias);
}

async function usage(req, env) {
  const a = await authenticate(req, env);
  if (a.error) return a.error;
  const plan = PLANS[a.rec.plan];
  return json({
    plan: a.rec.plan, plan_name: plan.name, status: a.rec.status, key_last4: a.rec.last4,
    period: monthKey(), used: await usageOf(env, a.hash), limit: plan.monthlyRequests, resets_on: nextMonthStart(),
  });
}

async function rotate(req, env) {
  const a = await authenticate(req, env);
  if (a.error) return a.error;
  const key = newKey();
  const hash = await sha256hex(key);
  const rec = { ...a.rec, last4: key.slice(-4), rotated: new Date().toISOString() };
  const used = await usageOf(env, a.hash);
  await env.AIV_KV.put('key:' + hash, JSON.stringify(rec));
  if (used) await env.AIV_KV.put(`use:${hash}:${monthKey()}`, String(used), { expirationTtl: 60 * 60 * 24 * 70 });
  if (rec.sub) await env.AIV_KV.put('sub:' + rec.sub, hash);
  await env.AIV_KV.delete('key:' + a.hash);
  return json({ key, plan: rec.plan, message: 'Your old key no longer works. Save this new key now; it will not be shown again.' });
}

async function claim(url, env) {
  const id = url.searchParams.get('session_id') || '';
  if (!/^cs_[A-Za-z0-9_]+$/.test(id)) return fail(400, 'Missing or invalid session_id.');
  const raw = await env.AIV_KV.get('claim:' + id);
  if (!raw) return fail(404, 'Your key is not ready yet, or it was already shown.', 'not_ready');
  await env.AIV_KV.delete('claim:' + id);
  const { key, plan } = JSON.parse(raw);
  return json({ key, plan, plan_name: PLANS[plan].name, monthly_requests: PLANS[plan].monthlyRequests });
}

// ---------- website chat (no customer key; protected by origin + per-IP limit) ----------
async function siteChat(req, env) {
  const origin = req.headers.get('Origin') || '';
  const allowed = siteOrigins(env);
  if (!allowed.includes(origin)) return fail(403, 'This endpoint only serves the AI Verse website.', 'forbidden', allowed[0] || '*');
  const ip = req.headers.get('CF-Connecting-IP') || 'unknown';
  const hourKey = `site:${await sha256hex(ip)}:${new Date().toISOString().slice(0, 13)}`;
  const n = Number(await env.AIV_KV.get(hourKey) || 0);
  if (n >= SITE_CHAT_PER_HOUR) return fail(429, 'You have reached the hourly limit for AIV. Please try again later.', 'rate_limited', origin);
  let body;
  try { body = await readJson(req); } catch (e) { return fail(400, e.message || 'Request body must be JSON.', undefined, origin); }
  const msgs = (Array.isArray(body.messages) ? body.messages : []).slice(-20)
    .filter(m => m && ['system', 'user', 'assistant'].includes(m.role) && typeof m.content === 'string')
    .map(m => ({ role: m.role, content: m.content.slice(0, 12000) }));
  if (!msgs.some(m => m.role === 'user')) return fail(400, 'No message to answer.', undefined, origin);
  await env.AIV_KV.put(hourKey, String(n + 1), { expirationTtl: 3700 });
  const payload = { model: MODELS[DEFAULT_MODEL].upstream, messages: msgs, stream: body.stream !== false, temperature: 0.5, max_completion_tokens: 1200, reasoning_effort: 'low' };
  return forwardToGroq(env, payload, origin, null);
}

// ---------- router ----------
export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const path = url.pathname.replace(/\/+$/, '') || '/';
    const origin = req.headers.get('Origin');
    if (req.method === 'OPTIONS') {
      const o = path === '/site/chat' ? (siteOrigins(env).includes(origin) ? origin : siteOrigins(env)[0] || '*') : '*';
      return new Response(null, { status: 204, headers: cors(o) });
    }
    try {
      if (path === '/stripe/webhook' && req.method === 'POST') return await handleWebhook(req, env);
      if (path === '/v1/chat/completions' && req.method === 'POST') return await chatCompletions(req, env);
      if (path === '/v1/models' && req.method === 'GET')
        return json({ object: 'list', data: Object.entries(MODELS).map(([id, m]) => ({ id, object: 'model', owned_by: 'ai-verse', description: m.description })) });
      if (path === '/v1/usage' && req.method === 'GET') return await usage(req, env);
      if (path === '/v1/keys/rotate' && req.method === 'POST') return await rotate(req, env);
      if (path === '/v1/claim' && req.method === 'GET') return await claim(url, env);
      if (path === '/site/chat' && req.method === 'POST') return await siteChat(req, env);
      if (path === '/') return json({ name: 'AI Verse API', docs: 'https://aiverse.it.com/api.html', status: 'ok' });
      return fail(404, `No route for ${req.method} ${path}.`, 'not_found');
    } catch (e) {
      return fail(500, 'Something went wrong on our side. Please try again.', 'server_error');
    }
  },
};

// exported for tests
export const _test = { verifyStripe, sha256hex, newKey, PLANS, MODELS };
