# AI Verse API — setup guide

This folder is the server that sells and checks AI Verse API keys. It runs on Cloudflare Workers (free to start). **Do not upload this folder to your GitHub Pages site.**

How the pieces fit:

```
Customer → api.html "Subscribe" → Stripe Checkout (monthly)
Stripe → Worker /stripe/webhook → creates key (stored as a hash)
Stripe redirects to api.html?session_id=… → page calls /v1/claim → key shown once
Customer's code → Worker /v1/chat/completions → checks key + plan → Groq → answer
Website AIV chat → Worker /site/chat → Groq (your Groq key stays hidden)
```

You need: a Cloudflare account, a Stripe account, your Groq key, and Node.js on your computer.

## 1. Deploy the Worker

```bash
cd server
npx wrangler login
npx wrangler kv namespace create AIV_KV
```
Copy the `id` it prints into `wrangler.toml` (`PASTE_YOUR_KV_NAMESPACE_ID`).

```bash
npx wrangler secret put GROQ_API_KEY        # paste your Groq key (gsk_…)
npx wrangler deploy
```
Wrangler prints your Worker address, for example `https://aiverse-api.YOURNAME.workers.dev`. Open it: you should see `{"name":"AI Verse API","status":"ok"}`.

Optional: in Cloudflare → Workers → aiverse-api → Settings → Domains, add `api.aiverse.it.com` so customers use your own address.

## 2. Create the plans in Stripe

1. Stripe → **Product catalog → Add product**. Create three products with a **recurring monthly** price, matching the plans in `aiv-api-worker.js` (`PLANS`) and `api.html`:
   - AIV API Starter — $9 / month — 5,000 requests
   - AIV API Pro — $29 / month — 25,000 requests
   - AIV API Business — $99 / month — 100,000 requests
2. Copy each **Price ID** (`price_…`) into `PRICE_IDS` in `wrangler.toml`.
3. For each product, **Create payment link**. Under *After payment*, choose **Don't show confirmation page → Redirect** and enter:
   `https://aiverse.it.com/api.html?session_id={CHECKOUT_SESSION_ID}`
   (type `{CHECKOUT_SESSION_ID}` exactly — Stripe fills it in).
4. Copy the three payment link URLs (`https://buy.stripe.com/…`) into `api.html` → `AIV_API_CONFIG.paymentLinks`.
5. **Settings → Billing → Customer portal**: turn it on (allow cancel, update payment method, switch plans between your three products). Copy the portal link into `AIV_API_CONFIG.portalUrl`.

## 3. Connect Stripe to the Worker

1. Stripe → **Developers → API keys**: copy the **Secret key**, then run `npx wrangler secret put STRIPE_SECRET_KEY`. (A restricted key with read access to Checkout Sessions also works.)
2. Stripe → **Developers → Webhooks → Add endpoint**:
   - URL: `https://YOUR-WORKER-ADDRESS/stripe/webhook`
   - Events: `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`
3. Copy the endpoint's **Signing secret** (`whsec_…`) and run `npx wrangler secret put STRIPE_WEBHOOK_SECRET`.
4. Run `npx wrangler deploy` again so the new `PRICE_IDS` take effect.

## 4. Point the website at the Worker

- `api.html` → `AIV_API_CONFIG.apiBase`: your Worker address (or `https://api.aiverse.it.com`).
- `chat.html` → `AIV_CONFIG.proxyUrl`: `https://YOUR-WORKER-ADDRESS/site/chat`, and set `groqKey` back to `''`. Your Groq key is now hidden from the public.
- If you test from a GitHub address (`https://USERNAME.github.io`), add it to `SITE_ORIGIN`, separated by a comma.

## 5. Test before going live

Use Stripe **test mode** first (test keys, test payment links, card `4242 4242 4242 4242`, any future date and CVC). Buy a plan, confirm `api.html` shows a key, then:

```bash
curl https://YOUR-WORKER-ADDRESS/v1/chat/completions \
  -H "Authorization: Bearer aiv_live_…" -H "Content-Type: application/json" \
  -d '{"model":"aiv-1","messages":[{"role":"user","content":"Hello"}]}'
```
When it works, repeat steps 2–3 in live mode with live keys.

## Things to know

- **Costs:** every request is paid to Groq from your Groq account. Each request is capped at 2,048 output tokens. Check Groq's current prices against your plan prices before launch, and add a payment method and spend limit in Groq so customer traffic isn't cut off by free-tier limits.
- **Cloudflare limits:** the free Workers plan allows 1,000 storage writes per day, and each API request uses one. Upgrade to Workers Paid ($5/month) before you have paying customers.
- **Usage counts are approximate** under heavy parallel traffic (a few extra requests can slip past a limit). Fine for launch.
- **Lost keys:** keys are stored only as hashes, so nobody (including you) can look one up. A customer who still has their key can replace it on `api.html`. If a key is lost, cancel and resubscribe through the portal, or contact support to issue one manually.
- **Privacy:** the Worker never stores prompts or answers. Requests are processed by Groq.
- **Legal:** before selling, publish Terms of Service and a Privacy Policy, and check that reselling Groq-powered access fits Groq's terms for your use.
- Change plan sizes in `PLANS` (Worker), `PRICE_IDS` (wrangler.toml) and the plan cards in `api.html` together.
